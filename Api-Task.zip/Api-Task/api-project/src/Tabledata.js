import Table from 'react-bootstrap/Table';
import React, { useState,useEffect } from 'react';



function Tabledata() {

    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState({});
    
    useEffect(() => {
        fetch("http://stage.backend.eggoz.in/sales/export/?warehouse=1&to_delivery_date=10/7/2021&from_delivery_date=9/7/2021")
          .then(res => res.json())
          .then(
            (result) => {
                debugger
              setIsLoaded(true);
              setItems(result.results);
              console.log(items)
              debugger
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
              setIsLoaded(true);
              setError(error);
            }
          )
      }, [])
    
      if (error) {
        return <div>Error: {error.message}</div>;
      } else if (!isLoaded) {
        return <div>Loading...</div>;
      } else {
      
    return (
        
        <div>{console.log("items",items)}
            <h1>Table api data</h1>
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                    <Table striped bordered hover responsive="lg" responsive="xl" size="md" size="lg" responsive="md">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Bill No</th>
                    <th>Retailer Name</th>
                    <th>Order Date</th>
                    <th>delivery Date</th>
                    <th>Quantity</th>
                    <th>Order Amount</th>
                    <th>status</th>
                    </tr>
                </thead>
               
                <tbody>
                     {items.map(item => (
                    <tr>
                    
                      
                       
                    <td>{item.Date}</td>
                    <td>{item.Mode}</td>
                    <td>{item.city_name}</td>
                    <td>{item.amount}</td>
                    <td>12-10-20</td>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                   
                    </tr>
                      ))}
                </tbody>
      
            </Table>

                    </div>
                </div>
            </div>
           
        </div>
    )
                    
}
}

export default Tabledata;