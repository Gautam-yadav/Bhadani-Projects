import React from "react"
import "./EmployeeRegister.css"
import { makeStyles } from "@material-ui/core/styles";
import Container from '@material-ui/core/Container';
import CachedIcon from '@material-ui/icons/Cached';


const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
  
    formhead: {
      justifyContent: "center",
      marginTop: "2rem",
      
    },
    d1:{
        justifyContent:"center"
    }
}));
const EmployeeRegister=()=>{
    const classes = useStyles();

    return(
        <>
        <div className={classes.root}>
            <div className={classes.d1}>
                <div className="heading">Employer Information</div>
                <CachedIcon className="cacheicon" />
            </div>
        <Container className={classes.formhead}>
        <h1>hskjdnk</h1>
        </Container>
        </div>
        </>
    )
}
export { EmployeeRegister }
