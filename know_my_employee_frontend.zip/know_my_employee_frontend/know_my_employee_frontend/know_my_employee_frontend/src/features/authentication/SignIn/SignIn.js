import React, { Fragment } from 'react'
import { Link, navigate } from '@reach/router'

import './sign.css'
import { Link as RouterLink } from '@reach/router'
import {
   Button,
   TextField,
   Box,
   makeStyles,
   Typography,
   InputAdornment,
   IconButton,
} from '@material-ui/core'
import VisibilityOffOutlinedIcon from '@material-ui/icons/VisibilityOffOutlined'
import VisibilityOutlinedIcon from '@material-ui/icons/VisibilityOutlined'
import { CommonStore, commonActionTypes } from '../../../data/stores/common'
import { toast } from 'react-toastify'
import { authenticationActionTypes, AuthenticationStore } from '../../../data/stores/authentication'

const useStyles = makeStyles((theme) => ({
   paper: {
      // marginTop: theme.spacing(4) - 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
   },
   form: {
      width: '350px', // Fix IE 11 issue.
      // marginTop: theme.spacing(1),
      margin: 'auto',
   },

   submit: {
      // margin: theme.spacing(3, 0, 2),
      background: theme.palette.primary.main,
      marginTop: theme.spacing(7),
      paddingTop: theme.spacing(3) - 3,
      paddingBottom: theme.spacing(3) - 3,
      boxShadow: '0px 5px 10px #E0E4EE',
      borderRadius: '5px',
      fontStyle: 'normal',
      fontWeight: '500',
      fontSize: '16px',
      lineHeight: '18px',
      textTransform: 'capitalize' /* identical to box height, or 112% */,
      textAlign: 'center',
      color: '#FFFFFF',
   },
   signUpGoogle: {
      background: '#FFFFFF',
      boxShadow: '0px 5px 10px #E0E4EE',
      paddingTop: theme.spacing(3) - 3,
      paddingBottom: theme.spacing(3) - 3,
      borderRadius: '5px',
      marginTop: '15px',
      fontStyle: 'normal',
      fontWeight: '500',
      fontSize: '16px',
      lineHeight: '18px',
      textAlign: 'center',
      textTransform: 'initial',
   },
   formInputControl: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      marginBottom: theme.spacing(4) - 2,
      position: 'relative',
      'p.Mui-error': { color: 'pink' },
   },
   togglePasswordDisplay: {
      position: 'absolute',
      right: theme.spacing(2) + 4,
      top: theme.spacing(7) - 3,
   },
   formInputLabel: {
      fontSize: '14px',
      fontStyle: 'normal',
      fontWeight: '400',
      lineHeight: '18px',
      letterSpacing: '0px',
      textAlign: 'left',
      color: '#A4A4A4',
      marginBottom: theme.spacing(1) - 2,
   },

   signUpHereBtn: {
      fontStyle: 'normal',
      fontWeight: 'normal',
      fontSize: '16px',
      lineHeight: '18px',
      /* identical to box height, or 129% */
      cursor: 'pointer',
      color: '#474ddc',
      textDecoration: 'none',
   },
   forgotPasswordLink: {
      color: '#474DDC',
      fontSize: '14px',
      fontStyle: 'normal',
      fontWeight: '400',
      lineHeight: '18px',
      letterSpacing: '0px',
      textAlign: 'left',
      marginTop: '10px',
      cursor: 'pointer',
      textDecoration: 'none',
   },
   formFooterLink: {
      marginTop: theme.spacing(5) + 5,
      textAlign: 'center',
   },
}))

function SignIn() {
   const [isPasswordVisible, setisPasswordVisible] = React.useState(false)
   const classes = useStyles()
   const { commonDispatch } = React.useContext(CommonStore)
   const { authenticationDispatch } = React.useContext(AuthenticationStore)
   const { authentication } = React.useContext(
      AuthenticationStore
   )
const {profileData} = authentication
console.log("profileData",profileData)
   // API Call
   const onSubmit = async ({ email, password }) => {
      // begin loading
      commonDispatch({ type: commonActionTypes.toggleLoading, payload: true })
      try {
         debugger
         // stop loading
         authenticationDispatch({
            type: authenticationActionTypes.setProfileData,
            payload: JSON.parse(
               JSON.stringify({ email:"abc@cd.com", password:"password" })
            ),
         })
         commonDispatch({
            type: commonActionTypes.toggleLoading,
            payload: false,
         })

      } catch (err) {
         // stop loading
         commonDispatch({
            type: commonActionTypes.toggleLoading,
            payload: false,
         })
         commonDispatch({
            type: commonActionTypes.setSnackBarErrorMessage,
            payload: err.message,
         })
         commonDispatch({ type: commonActionTypes.toggleSnackBarError })
         return err
      }
   }

   return (
         <form
            className={classes.form}
            noValidate
            onSubmit={()=>onSubmit()}
         >
            <Box className={classes.formInputControl}>
               <label className={classes.formInputLabel}>Email Address</label>
               <TextField
                  hiddenLabel
                  className={classes.formInput}
                  variant='outlined'
                  required
                  fullWidth
                  id='email'
                  name='email'
                  type='email'
                  autoFocus
                  // inputRef={register}
                  // error={errors?.email?.message && true}
                  // helperText={errors?.email?.message && errors.email.message}
               />
            </Box>


            <Box className={classes.formInputControl}>
               <label className={classes.formInputLabel}>Password </label>
               <TextField
                  type={isPasswordVisible ? 'text' : 'password'}
                  id='password'
                  name='password'
                  variant='outlined'
                  fullWidth
                  required
                  // inputRef={register}
                  // error={errors?.password?.message && true}
                  // helperText={   errors?.password?.message && errors?.password?.message}
               />
               <Typography
                  variant='subtitle2'
                  className={classes.forgotPasswordLink}
                  component='h6'
               >
                  <Link
                     component={RouterLink}
                     underline='none'
                     to='/auth/forgot-password'
                  >
                     Forgot Password?
                  </Link>
               </Typography>

               <Box className={classes.togglePasswordDisplay}>
                  <InputAdornment position='end'>
                     <IconButton
                        aria-label='toggle password visibility'
                        onClick={() => {
                           setisPasswordVisible(!isPasswordVisible)
                        }}
                        edge='end'
                     >
                        {isPasswordVisible ? (
                           <VisibilityOffOutlinedIcon />
                        ) : (
                           <VisibilityOutlinedIcon />
                        )}
                     </IconButton>
                  </InputAdornment>
               </Box>
            </Box>


            <Button
               type='submit'
               fullWidth
               variant='contained'
               color='primary'
               className={classes.submit}
            >
               Login
            </Button>
            <Box
               display='flex'
               alignItems='center'
               justifyContent='space-around'
               className={classes.formFooterLink}
            >
            </Box>
         </form>
   )
}
export { SignIn }
