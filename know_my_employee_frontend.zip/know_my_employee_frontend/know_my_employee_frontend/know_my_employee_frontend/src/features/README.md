# `features/`

Contains React components grouped by functionality. As opposed to the
`pages` directory, these component are reusable, either within a single
page or throughout the application. One-off components will go in the
`common/components` directory (e.g., `common/components/SimpleDialog.js`).

### Example 1

`pages/Authentication` is a container the components
`features/authentication` which are swapped out with a router.

### Example 2

`feautures/messenger` components are used in several places throughout the
application but have related funcationality.
