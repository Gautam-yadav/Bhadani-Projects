import React, { createContext, useReducer } from 'react'
import { produce } from 'immer'

const initialCommonState = {
   isLoading: false,
   themeType: 'light',
   // SnackBar Error
   snackBarError: false,
   snackBarErrorMessage: null,
   privateRoute: { index: 0 },
   isGroupSelected: false,
   selectedGroupID: '',
   groupAuthorData: null,
   notificationData: '',
   removeNotificationData: '',
   isMessengerOpen:false,
   isChatBox:false,
   currentUser:null,
   updateNotification:false,
   selectedType:0

}

const CommonStore = createContext(initialCommonState)

const commonActionTypes = {
   toggleLoading: 'TOGGLE_LOADING',
   setTheme: 'SET_THEME',
   // SnackBar Error
   toggleSnackBarError: 'TOGGLE_SNACK_BAR_ERROR',
   setSnackBarErrorMessage: 'SET_SNACK_BAR_ERROR_MESSAGE',
   setPrivateRoute: 'SET_PRIVATE_ROUTE',
   setIsGroupSelected: 'SET_IS_GROUP_SELECTED',
   SetSelectedGroupID: 'SET_SELECTED_GROUP_ID',
   setGroupAutherData: 'SET_GROUP_AUTHOR_DATA',
   setNotificationData: 'SET_NOTIFICATION_DATA',
   setRemoveNotificationData: 'REMOVE_NOTIFICATION_DATA',
   setIsMessengerOpen: 'SET_IS_MESSENGER_OPEN',
   setIsChatBox: 'SET_IS_CHAT_BOX',
   setCurrentUser: 'SET_CURRENT_USER',
   setUpdateNotification:'SET_UPDATE_NOTIFICATION',
   setSelectedType:'SET_SELECTED_TYPE'


}

function commonReducer(state, action) {
   const { type } = action
   switch (type) {
      case commonActionTypes.toggleLoading:
         return produce(state, (draftState) => {
            draftState.isLoading = action.payload
         })
      case commonActionTypes.setTheme:
         return produce(state, (draftState) => {
            draftState.themeType = action.payload
         })
      // SnackBar Error
      case commonActionTypes.toggleSnackBarError:
         return produce(state, (draftState) => {
            draftState.snackBarError = !draftState.snackBarError
         })
      case commonActionTypes.setSnackBarErrorMessage:
         return produce(state, (draftState) => {
            draftState.snackBarErrorMessage = action.payload
         })
      case commonActionTypes.setPrivateRoute:
         return produce(state, (draftState) => {
            draftState.privateRoute = action.payload
         })
      case commonActionTypes.setIsGroupSelected:
         return produce(state, (draftState) => {
            draftState.isGroupSelected = action.payload
         })
      case commonActionTypes.SetSelectedGroupID:
         return produce(state, (draftState) => {
            draftState.selectedGroupID = action.payload
         })
      case commonActionTypes.setGroupAutherData:
         return produce(state, (draftState) => {
            draftState.groupAuthorData = action.payload
         })
      case commonActionTypes.setNotificationData:
         return produce(state, (draftState) => {
            draftState.notificationData = action.payload
         })
      case commonActionTypes.setRemoveNotificationData:
         return produce(state, (draftState) => {
            draftState.removeNotificationData = action.payload
         })
      case commonActionTypes.setIsMessengerOpen:
         return produce(state, (draftState) => {
               draftState.isMessengerOpen = action.payload
            })
      case commonActionTypes.setIsChatBox:
         return produce(state, (draftState) => {
            draftState.isChatBox = action.payload
         })
      case commonActionTypes.setCurrentUser:
         return produce(state, (draftState) => {
            draftState.currentUser = action.payload
         })
      case commonActionTypes.setUpdateNotification:
         return produce(state, (draftState) => {
            draftState.updateNotification = action.payload
      })
      case commonActionTypes.setSelectedType:
         return produce(state, (draftState) => {
            draftState.selectedType = action.payload
      })
      

      default:
         return state
   }
}

function CommonProvider({ children }) {
   const [common, commonDispatch] = useReducer(
      commonReducer,
      initialCommonState,
   )

   return (
      <CommonStore.Provider value={{ common, commonDispatch }}>
         {children}
      </CommonStore.Provider>
   )
}

export { CommonStore, commonActionTypes, commonReducer, CommonProvider }
