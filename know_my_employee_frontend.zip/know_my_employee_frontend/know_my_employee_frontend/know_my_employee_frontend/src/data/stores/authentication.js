import React, { createContext, useReducer } from 'react'
import { produce } from 'immer'

const initialAuthenticationState = {
   isAuthenticated: false,
   profileData: {}
}

const AuthenticationStore = createContext(initialAuthenticationState)

const authenticationActionTypes = {
   toggleAuthenticated: 'TOGGLE_AUTHENTICATED',
   setProfileData: 'SET_PROFILE_DATA',
}

function authReducer(state, action) {
   const { type } = action
   switch (type) {
      case authenticationActionTypes.toggleAuthenticated:
         return produce(state, (draftState) => {
            draftState.isAuthenticated = action.payload
         })
      case authenticationActionTypes.setProfileData:
         return produce(state, (draftState) => {
            draftState.profileData = action.payload
         })
      default:
         return state
   }
}

function AuthenticationProvider({ children }) {
   const [authentication, authenticationDispatch] = useReducer(
      authReducer,
      initialAuthenticationState,
   )
   return (
      <AuthenticationStore.Provider
         value={{ authentication, authenticationDispatch }}
      >
         {children}
      </AuthenticationStore.Provider>
   )
}

export {
   AuthenticationStore,
   authenticationActionTypes,
   authReducer,
   AuthenticationProvider,
}
