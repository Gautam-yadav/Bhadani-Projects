import React, { useEffect } from 'react'
import {
   Container,
   Button,
   Grid,
   Typography,
   makeStyles,
   fade,
} from '@material-ui/core'
import { Copyright } from '../../common/components'
import { navigate } from '@reach/router'

const useStyles = makeStyles((theme) => ({
   grow: {
      flexGrow: 1,
   },
   search: {
      position: 'relative',
      borderRadius: theme.shape.borderRadius,
      backgroundColor: fade(theme.palette.common.white, 0.15),
      '&:hover': {
         backgroundColor: fade(theme.palette.common.white, 0.25),
      },
      marginRight: theme.spacing(2),
      marginLeft: 0,
      width: '100%',
      [theme.breakpoints.up('sm')]: {
         marginLeft: theme.spacing(3),
         width: 'auto',
      },
   },
   searchIcon: {
      padding: theme.spacing(0, 2),
      height: '100%',
      position: 'absolute',
      pointerEvents: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
   },
   iconSm: {
      color: theme.palette.common.white,
      backgroundColor: fade(theme.palette.common.white, 0.15),
      '&:hover': {
         backgroundColor: fade(theme.palette.common.white, 0.25),
      },
   },
   inputRoot: {
      color: 'inherit',
   },
   inputInput: {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('md')]: {
         width: '20ch',
      },
   },
   icon: {
      marginRight: theme.spacing(2),
   },
   heroContent: {
      backgroundColor: theme.palette.background.paper,
      padding: theme.spacing(8, 0, 6),
   },
   heroButtons: {
      marginTop: theme.spacing(4),
   },
   cardGrid: {
      paddingTop: theme.spacing(8),
      paddingBottom: theme.spacing(8),
   },
   card: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
   },
   cardMedia: {
      paddingTop: '56.25%', // 16:9
   },
   cardContent: {
      flexGrow: 1,
   },
   footer: {
      backgroundColor: theme.palette.background.paper,
      padding: theme.spacing(1),
      position: 'absolute',
      bottom: '0',
      width: '100%',
   },
}))

function Landing() {
   const classes = useStyles()
   const handleAboutMeDialogOpen = () => {
      const newWindow = window.open(
         `https://www.lighthouse-library.com/`,
         '_blank',
         'noopener,noreferrer',
      )
      if (newWindow) newWindow.opener = null
   }

   useEffect(() => {
      if (localStorage.getItem(process.env.REACT_APP_COGNITO_USER)?.length > 0) {
         navigate('/dashboard')
      }
   }, [])
   return (
      <React.Fragment>
         {/* <NavBar /> */}
         <main>
            <div className={classes.heroContent}>
               <Container maxWidth='sm'>
                  <Typography
                     component='h1'
                     variant='h2'
                     align='center'
                     color='textPrimary'
                     gutterBottom
                  >
                     Lighthouse
                  </Typography>
                  <Typography
                     variant='h4'
                     align='center'
                     color='textSecondary'
                     paragraph
                  >
                     Solve the world's greatest challenges.{' '}
                  </Typography>
                  <Typography
                     variant='h5'
                     align='center'
                     color='textPrimary'
                     paragraph
                  >
                     Find others, create, and innovate together.{' '}
                  </Typography>
                  <Typography
                     variant='h5'
                     align='center'
                     color='textPrimary'
                     paragraph
                  >
                     Currently configured for desktop only.{' '}
                  </Typography>

                  <div className={classes.heroButtons}>
                     <Grid container spacing={2} justify='center'>
                        <Grid item>
                           <Button
                              variant='outlined'
                              color='primary'
                              onClick={handleAboutMeDialogOpen}
                           >
                              Learn More
                           </Button>
                        </Grid>
                     </Grid>
                  </div>
               </Container>
            </div>
         </main>
         {/* Footer */}
         <footer className={classes.footer}>
            <Copyright />
         </footer>
         {/* End footer */}
      </React.Fragment>
   )
}

export { Landing }
