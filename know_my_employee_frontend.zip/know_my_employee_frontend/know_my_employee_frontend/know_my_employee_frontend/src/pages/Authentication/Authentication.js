// Router for `pages/Authentication`
import React from 'react'
import { Link as RouterLink, Router } from '@reach/router'
import { Error } from '../Error'
import { Grid } from '@material-ui/core'
import { SignIn,EmployeeRegister } from '../../features/authentication'


function Authentication({ loadingToggler }) {
   const [userCreds, setUserCreds] = React.useState({ email: null })
   return  (
         <Grid container direction='column' alignItems='center'>
            <Grid item xs={12} sm={12}>
               <Router>
                  <SignIn
                     path='sign-in'
                     loadingToggler={loadingToggler}
                     setUserCreds={setUserCreds}
                     userCreds={userCreds}
                  />
                  <EmployeeRegister path='register'/>
                  

                  <Error default />
               </Router>
            </Grid>
         </Grid>
   )
}

export { Authentication }
