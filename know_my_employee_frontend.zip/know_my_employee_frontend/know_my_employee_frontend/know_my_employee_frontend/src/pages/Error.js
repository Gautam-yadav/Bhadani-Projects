import React from 'react'
import { Link as RouterLink } from '@reach/router'
import {
   makeStyles,
   Grid,
   Paper,
      Button,
   Typography,
   CssBaseline,
} from '@material-ui/core'
import { Copyright } from '../common/components'

const useStyles = makeStyles((theme) => ({
   root: { flexFlow: 1 },
   paper: {
      padding: theme.spacing(2),
      textAlign: 'center',
      color: theme.palette.text.disabled,
      maxWidth: '80vw',
      margin: 'auto',
   },
   image: { width: '70vw' },
   img: {
      margin: 'auto',
      display: 'block',
      maxWidth: '100%',
      maxHeight: '100%',
   },
}))

function Error() {
   const classes = useStyles()

   return (
      <Grid
         container
         component='main'
         direction='column'
         justify='center'
         alignItems='center'
         spacing={3}
         className={classes.root}
      >
         <CssBaseline />

         <Paper
            className={classes.image}
            style={{
               backgroundImage: `url()`,
            }}
         />
         <Typography variant='h1'>404</Typography>
         <Typography variant='h3'> Oh No!</Typography>
        <Typography variant='h5'>You've reached this page in error.</Typography>
        <br/>
        <Button variant='contained' color='primary' component={RouterLink} to='/'> Click here to go to the Lighthouse home page</Button>
         <img
            className='classes.image'
            src={
               'https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif'
            }
           alt='404, caveman biting a wire'
         />
        <Copyright />
      </Grid>
   )
}

export { Error }
