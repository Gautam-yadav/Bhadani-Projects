import React from "react"


function header(){
    return(
        <>
        <img src="./know-my-employee.png" alt="load" />
        </>

    )
}

export {header}