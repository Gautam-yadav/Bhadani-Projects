# `common/components`

Reusable components that neither are related to any specific feature nor require
any specific feature logic or data.
