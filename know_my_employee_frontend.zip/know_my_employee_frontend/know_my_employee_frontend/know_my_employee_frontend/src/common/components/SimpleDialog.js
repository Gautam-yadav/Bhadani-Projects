import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import DialogTitle from '@material-ui/core/DialogTitle'
import Dialog from '@material-ui/core/Dialog'
import Typography from '@material-ui/core/Typography'

const useStyles = makeStyles((theme) => ({
   message: {
      padding: theme.spacing(1),
      textAlign: 'center',
   },
}))

function SimpleDialog({ title = null, message = '', onClose, open }) {
   const classes = useStyles()
   const handleClose = () => onClose()
   return (
      <Dialog
         onClose={handleClose}
         aria-labelledby='simple-dialog-title'
         open={open}
      >
         {title && <DialogTitle id='simple-dialog-title'>{title}</DialogTitle>}
         <Typography className={classes.message} variant='body1'>
            {' '}
            {message}
         </Typography>
      </Dialog>
   )
}

export { SimpleDialog }
