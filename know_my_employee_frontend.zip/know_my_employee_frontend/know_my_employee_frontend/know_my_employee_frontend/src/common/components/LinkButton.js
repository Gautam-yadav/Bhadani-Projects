import React from 'react'
import { Link } from '@reach/router'
import { Button } from '@material-ui/core'

function LinkButton({ url, buttonText }) {
   return (
      <Button color='primary' component={Link} to={url}>
         {buttonText}
      </Button>
   )
}

export { LinkButton }
