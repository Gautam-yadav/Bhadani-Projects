import React from 'react'
import { Snackbar as MuiSnackbar, makeStyles } from '@material-ui/core'
import { Alert as MuiAlert } from '@material-ui/lab'
import { CommonStore, commonActionTypes } from '../../data/stores/common'

function Alert(props) {
   return <MuiAlert elevation={6} variant='filled' {...props} />
}

const useStyles = makeStyles((theme) => ({
   root: {
      width: '100%',
      '& > * + *': {
         marginTop: theme.spacing(2),
      },
   },
}))

function Snackbar({ snackbarSeverity = 'error', open, setOpen }) {
   const classes = useStyles()
   const { common, commonDispatch } = React.useContext(CommonStore)
   const { snackBarErrorMessage } = common
   const handleClose = (event, reason) => {
      if (reason === 'clickaway') {
         return
      }
      setOpen(false)
      commonDispatch({
         type: commonActionTypes.setSnackBarErrorMessage,
         payload: null,
      })
   }

   return (
      <div className={classes.root}>
         <MuiSnackbar open={open} autoHideDuration={6000} onClose={handleClose}>
            <Alert onClose={handleClose} severity={snackbarSeverity}>
               {snackBarErrorMessage}
            </Alert>
         </MuiSnackbar>
      </div>
   )
}

export { Snackbar }
