import React from 'react'
import { Link as RouterLink } from '@reach/router'
import { Typography, Link } from '@material-ui/core'

function Copyright() {
   return (
      <Typography variant='body2' color='textSecondary' align='center'>
         {'Copyright © '}
         <Link color='inherit' component={RouterLink} to='/'>
            {process.env.REACT_APP_BUSINESS_NAME},
         </Link>{' '}
         {new Date().getFullYear()}
         {'.'}
      </Typography>
   )
}

export { Copyright }
