import React from 'react'
import { AiOutlineCheckCircle as CheckIcon } from 'react-icons/ai'
import { motion } from 'framer-motion'

const green = '#50C878'

const SuccessAnimation = () => (
   <motion.div>
      <CheckIcon size='2em' color={green} />
   </motion.div>
)

export { SuccessAnimation }
