# `common/`

Contains code that is not related to a specific feature can can be
used through the application
