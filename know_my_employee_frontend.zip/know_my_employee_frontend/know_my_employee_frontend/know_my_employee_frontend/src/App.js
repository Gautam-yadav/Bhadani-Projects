// Composes routes and static components
import React from 'react'
import { Router } from '@reach/router'
import { CommonStore, commonActionTypes } from '../src/data/stores/common'

import {
   ThemeProvider,
   createMuiTheme,
   Backdrop,
   CircularProgress,
   makeStyles,
   Box,
   CssBaseline,
} from '@material-ui/core'
import { Snackbar } from './common/components'
import { Landing, Authentication, Error,} from './pages'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'


const useStyles = makeStyles((theme) => ({
   mainContainer: {
      all: 'none',
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100vh',
   },
   backdrop: {
      zIndex: theme.zIndex.appBar + 1000,
      color: '#fff',
   },

   app: {
      // maxWidth: '1800px',
      // margin: 'auto',
      minHeight: '100%',
   },
}))

function Routing() {
   return (
      <>
         <ToastContainer position='top-right' />
         <Router>
            <Landing path='/' />
            {/* <Route path="/register" exact component={EmployeeRegister}/> */}
            
            <Authentication path='auth/*' />
            <Error default />
         </Router>
      </>
   )
}

const App = () => {
   const classes = useStyles()
     // Theme

   // Loading state for entire app
   const { common, commonDispatch } = React.useContext(CommonStore)
   const { isLoading, themeType, snackBarError, snackBarErrorMessage } = common
   return (
      <ThemeProvider>
         <CssBaseline />
         <Box className={classes.app}>
            <main className={classes.mainContainer}>
               <Routing />
            </main>
            <Backdrop className={classes.backdrop} open={isLoading}>
               <CircularProgress color='inherit' />
            </Backdrop>
            <Snackbar
               open={snackBarError}
               setOpen={() =>
                  commonDispatch({
                     type: commonActionTypes.toggleSnackBarError,
                  })
               }
               handleChange={() =>
                  commonDispatch({
                     type: commonActionTypes.toggleSnackBarError,
                  })
               }
               message={snackBarErrorMessage}
            />
            {/* <Footer /> */}
         </Box>
      </ThemeProvider>
   )
}

export default  App 
