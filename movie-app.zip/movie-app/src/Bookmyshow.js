import React, { Component } from "react";
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'
import axios from "axios"
class Bookmyshow extends Component {
  constructor(props){
    super(props)

    this.state = {
      movieList: []
    }
  
  }



  componentDidMount(){

    axios.get(`http://www.omdbapi.com/?s=thor&apikey=f7cc51b4`)
    .then((res) => {

      console.log(res.data.Search , "pp")
      // this.setState({})
      this.setState( ({
        movieList: [ ...res.data.Search]
      }))
      console.log(this.state.movieList , "??")
    })


    
    // fetch('http://www.omdbapi.com/?s=thor&apikey=f7cc51b4').then((res)=>{
    //   debugger
    //   res.json(res)
    //   console.log(res.data.Search)
    //   this.setState({movieList: res})
    // }).catch((err)=>{
    //   console.log(err)
    // })

  }



  render() {
    {   console.log(this.state.movieList , "??")}
    return (

      <>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12">
              <div className="parent-div">
                <h1 className="h1">Movie section</h1>
              </div>
            </div>
            
          </div>
        </div>
        <div className="container">
        <div className="row">



{/* 
          {this.state.movieList.length > 0 ? this.state.movieList.map((ele, index)=>{
            return(
              <>
            <div className="col-md-3 mb-5" >
              <Card style={{ width: "18rem" }}>
               <Card.Img variant="top" src="https://i.ibb.co/Cz5mhFH/women.jpg" />
                <Card.Body>
                <Card.Title>Card Title {ele}</Card.Title>
                <Card.Text className="black description">
                  Some quick example text to build on the card 
                </Card.Text>
                <div className="h4 black tittle">Movie Name</div>
              </Card.Body>
            </Card>
          </div>

              </>
            )
          }): null} */}



           {this.state.movieList.map((ele, index)=>{
            return  <div className="col-md-3 mb-5" key={index} >
            <Card style={{ width: "18rem" }}>
             <Card.Img variant="top" src={ele.Poster} />
              <Card.Body>
              {/* <Card.Title>{ele.Title}</Card.Title> */}
              <Card.Text className="black description">
              {ele.Year}
              </Card.Text>
              <div className="h4 black tittle">  {ele.Title}</div>
            </Card.Body>
          </Card>
        </div>
          })}
         

             
           
            </div>
        </div>
      </>
    );
  }
}

export default Bookmyshow;
