import React from 'react'
function Newuser(props) {

    return (
        <div>
            <span className="mine">New User {props.data.name}</span>
            <br></br>
            <span className="mine">New User {props.data.email}</span>
            <br></br>
            <span className="mine">New User {props.data.address}</span>
            <br></br>
        </div>
    )
}

export default Newuser;