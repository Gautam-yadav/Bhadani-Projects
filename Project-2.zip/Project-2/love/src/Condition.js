import react,{useState} from 'react'

function Condition() {
    const [loggedIn, setLoggedIn]=useState(false)
  return (
    <div>
        {loggedIn==1?<h1>Welcome to User1 </h1>
        // :<h1>Welcome Guest</h1>}
              :loggedIn==2?<h1>Welcome to User1 </h1>
             :<h1>Welcome User3</h1>} 
        
      
    </div>
      )
}

export default Condition;