// import { getDefaultNormalizer } from "@testing-library/react";
// import react, { useState, useEffect } from "react";
// import React from "react";
// import Button from 'react-bootstrap/Button'
// import Table from 'react-bootstrap/Table'
// function Tabled() {
//   const data= "gautam";
//   const users = [
//     { name: 'gautam', age: '26',email:'manali28@gmail.com' , address:'gurgoan', },
//     { name: 'anil', age: '27', address:'delhi', email:'gautam.yadav28@gmail.com' },
//     { name: 'rao', age: '22', address:'delhi', email:'gautam.yadav@gmail.com' },
//     { name: 'sam', age: '26', address:'sec-86', email:'sam.yadav@gmail.com' },
//   ]
  
//   return (
//     <div>
//       <h1>Table component</h1>
//       <h2>{data}</h2>
//       <Button className="mb-3" variant="primary">Primary</Button>
//       <Table striped bordered hover>
//       <tbody>
//     <tr>
//     <td>serial No.</td>
//       <td>First Name</td>
//       <td>Age</td>
//       <td>address</td>
//       <td>email</td>
//     </tr>
//    {
//      users.map((item,i)=>
//       item.age === '26'?
//       <tr key={i}>
//       <td>{i}</td>
//       <td>{item.name}</td>
//       <td>{item.age}</td>
//       <td>{item.address}</td>
//       <td>{item.email}</td>
//     </tr>:null
//      )
//    }
    
//   </tbody>
// </Table>
// </div>
//   );
// }

// export default Tabled;
