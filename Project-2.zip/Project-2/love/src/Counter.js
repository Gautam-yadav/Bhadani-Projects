import React,{PureComponent} from 'react'

class Counter extends React.Component{

    render()
    {
        console.warn("component rerender")
        return(
            <div className="Counter">
                <h1>User Component user{this.props.count}</h1>
                 
            </div>
        );
    }
}

export default Counter;