import react,{useState} from 'react'

function Member(props) {
    
  return (
    <div>
        <h1>Member Component</h1>
      
    </div>
      )
}

export default Member;