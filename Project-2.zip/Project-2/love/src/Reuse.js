// import React from "react";
// import Button from "react-bootstrap/Button";
// import Table from "react-bootstrap/Table";
// import Newuser from './Newuser';
// function Reuse() {

//     const userdata = [
//         { name: 'gautam', age: '26',email:'manali28@gmail.com' , address:'gurgoan', },
//         { name: 'anil', age: '27', address:'delhi', email:'gautam.yadav28@gmail.com' },
//         { name: 'rao', age: '22', address:'delhi', email:'gautam.yadav@gmail.com' },
//         { name: 'sam', age: '26', address:'sec-86', email:'sam.yadav@gmail.com' },
//       ]
//     return (
//         <>
//         <h1>Reuse Component</h1>
       
//         {
//             userdata.map((item,i)=>
//             <Newuser data={item} key={i}/>
//             )
//         }
//         </>
//     )
// }

// export default Reuse;