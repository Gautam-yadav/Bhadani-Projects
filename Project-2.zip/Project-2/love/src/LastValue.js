import React,{useState} from 'react'
function LastValue(){
    const [count,setCount] = useState(1)
    function updateCounter()
     {
        let rand = Math.floor(Math.random()*10)
        setCount((pre)=>{
            console.warn(pre)
            // if(pre<5)
            // {
            //     alert ("low value")
            // }
            
                return rand;

        })

    }        
    
    return (
        <div>
            <h1>{count}</h1>
            <button onClick={updateCounter}>Click Me to Update counter</button>
        </div>
    );
}
export default  LastValue;