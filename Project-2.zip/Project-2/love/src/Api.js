// import { Divider } from '@material-ui/core'
// import React,{useState} from 'react'

// function Api(){
//     const [user,setUser] = useState([])
//     const [name,setName] = useState("");
//     const [email,setEmail] = useState("");
//     const [mobile,setMobile] = useState("");
//     const [userId,setUserId] = useState(null);

//     useEffect(() => {
//         getUsers();
//         },[])
//         function getUsers(){
//             fetch("https://jsonplaceholder.typicode.com/todos/1").then((result)=>{
//                 result.json().then((resp)=>{
//                     setUser(resp)=>
//                     setName(resp[0].name)
//                     setEmail(resp[0].email)
//                     setMobile(resp[0].mobile);
//                     setUserId(resp[0].id);

//                 })
//             })
//         }
//         function deleteUsers(Id){
//             fetch("https://jsonplaceholder.typicode.com/todos/1${id}"),{
//                 method:'DELETE'
//             }).then((result)=>{
//                 result.json().then(resp)=>{
//                     console.warn(resp)
//                     getUsers()
                    
//                 })
//             })
        
//         function salectUser(Id)
//         {
//          console.warn("function called",users[Id-1])
//                 let item=user[Id-1];
//                 setUser(item.name)
//                 setUEmail(item.email)
//                 setMobile(item.mobile);
//                 setMobile(item.Id);

//                 }
            
//         function UpdateUser()
//         {
//             console.warn(name.email.mobile)
//         }
        
        

//     return(
//         <div>
//             <h1>Api</h1>
//         </div>
//     );
// }
// export default Api;