import react,{useState} from 'react'

function Props(props) {
    
  return (
    <div>
        <h1>Member Component</h1>
      <button onClick={props.data}>Call Data function</button>
    </div>
      )
}

export default Props;