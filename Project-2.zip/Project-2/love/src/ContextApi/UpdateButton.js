import React from 'react';
import { CommonContext } from './CommonContext'
function UpdateButton(){
    
        return(
            
                
                <CommonContext.Consumer >
                    {
                        ({updateColor})=>(
                            <div>
                        <button className="btn bg-warning" onClick={()=>updateColor('yellow')}
                        >Update Yellow Button</button>

                        <button className="btn bg-primary ml-md-2" onClick={()=>updateColor('blue')}
                        >Update Blue Button</button>

                        <button className="btn bg-success ml-md-2" onClick={()=>updateColor('aqua')}
                        >Update aqua Button</button>
                            </div>
                         
                        )
                    }
                </CommonContext.Consumer >
                
                
            
        );
    }

export default UpdateButton;