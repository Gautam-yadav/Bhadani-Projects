// import React,{useState,useEffect,useRef} from 'react'

// function PreviousPropsHooks(props){

//     const lastVal=useRef();
//     useEffect(()=>{
//         lastVal.current=props.count
//     })
//     const PreviousProps=lastVal.current
//     console.warn(lastVal.current)
//     return(
//         <div>
//             <h1>
//             Previous Props Hooks child component
//             </h1>
//             <h1>{props.count}</h1>
//             <h2>previous props{PreviousProps}</h2>
//         </div>
//     )
// }
// export default PreviousPropsHooks;