import React from "react";
import ReactDOM from "react-dom";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import Sitelogo from "./know-my-employee-logo.png";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import { makeStyles } from "@material-ui/core/styles";
import { FaRegWindowClose } from "react-icons/fa";
import Input from "@material-ui/core/Input";
import TextField from "@material-ui/core/TextField";
import Checkbox from "@material-ui/core/Checkbox";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormLabel from "@material-ui/core/FormLabel";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { userSchema } from "./userValidation";
import Box from "@material-ui/core/Box";
import Portal from '@material-ui/core/Portal';
import Icon from '@material-ui/core/Icon';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },

  formhead: {
    justifyContent: "center",
    marginTop: "2rem",
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
    justifyContent: "center",
  },
  heading: {
    color: "#008dd2",
    position: "relative",
  },
  icon: {
    color: "#000",
    position: "absolute",
    right: "0px",
  },
  sec: {
    width: "100%",
  },
  secinner: {
    width: "100%",
    minHeight: "80px",
  },
  bluetext: {
    color: "#008dd2",
    padding:'0px 4px',
  },
  agreeTerms: {
    display: "flex",
    alignItems: "center",
    height: "100%",
    minHeight: "43px",
    flexWrap: "wrap",
  },
}));

function ReviewForm() {
  const classes = useStyles();
  const createUser = (event) => {
    event.preventDefault();
    let formData = {
      name: event.target[0].value,
      email: event.target[1].value,
      password: event.target[2].value,
    };
    console.log(formData);
  };
  return (
    <>
      <div className={classes.root}>
        <Grid container className={classes.formhead}>
          <Grid item sm={8} lg={6} xs={12}>
            <Paper className={classes.paper}>
              
                <Box variant="h2" component="h2" className={classes.heading}>
                  Employeer Information
                  <Box varient="span" component="span" className={classes.icon}>
                    <FaRegWindowClose />
                  </Box>
                </Box>
                <Typography
                  varient="form"
                  component="form"
                  className={classes.root}
                  noValidate
                  autoComplete="off"
                >
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-basic"
                      label="Name"
                      color="secondary"
                      className={classes.secinner}
                      placeholder="Name"
                    />
                  </Box>
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-new"
                      label="Company Name"
                      color="secondary"
                      className={classes.secinner}
                      type="text"
                      placeholder="Company Name"
                    />
                  </Box>
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-new"
                      label="Website Url"
                      color="secondary"
                      type="url"
                      className={classes.secinner}
                      placeholder="Website Url"
                    />
                  </Box>
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-new"
                      label="Bussiness Email"
                      color="secondary"
                      type="email"
                      placeholder="Bussiness Email"
                      className={classes.secinner}
                    />
                  </Box>
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-new"
                      label="Contact Number"
                      color="secondary"
                      type="number"
                      placeholder="Contact Number"
                      className={classes.secinner}
                    />
                  </Box>
                  <Box className={classes.sec} clone>
                    <TextField
                      id="standard-new"
                      label="Designation"
                      color="secondary"
                      type="text"
                      placeholder="Designation"
                      className={classes.secinner}
                    />
                  </Box>
                  <FormGroup aria-label="position" row>
                    <FormControlLabel
                      control={<Checkbox color="primary" />}
                      color="primary"
                      
                    />
                    <Typography  className={classes.agreeTerms}>
                      i agree to the 
                      <span className={classes.bluetext}>
                         terms and conditions
                      </span>{" "}
                      and{" "}
                      <span className={classes.bluetext}> privacy policy </span>
                    </Typography>
                  </FormGroup>
                  <button
                    type="submit"
                    color="primary"
                    className="btn btn-info btn-deign mt-3"
                  >
                    Continue
                  </button>
                </Typography>
              
            </Paper>
          </Grid>
        </Grid>
      </div>
    </>
  );
}

export default ReviewForm;
