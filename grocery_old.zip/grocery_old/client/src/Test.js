import {React,useState,useEffect} from 'react'
import axios from 'axios';



function Test() {

    // const axios = require('axios');
 const [responseData, setresponseData] = useState([])
 const [responseDataFetch, setresponseDataFetch] = useState([])

 useEffect(async() => {
   debugger
      const response = await fetch(
        `http://api.openweathermap.org/data/2.5/weather?q=gurugram&appid=4ea8f345f660789c426b1282d9a41f67`
      );
      const resJson = await response.json();
      setresponseDataFetch(resJson.main);
 
    
  }, []);



    function apiData(data) {
        console.log("hey garima")
        axios.get('https://api.publicapis.org/entries')
            .then(function (response) {
                // handle success
                debugger
                let data=response.data.entries
                setresponseData([...data])
                console.log(response);
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            
                   
    }
    console.log("responseData",responseData)

   

          return (
            <div>

            <h1 onClick={()=>{apiData()}}>I am Test for gautam</h1>
            
            <thead>
            {responseData.length>0 ? responseData.map((ele, index) => {
                return(
                    <> 
                     <tr>
                        <th scope="col">#</th>
                        <th scope="col">First</th>
                        <th scope="col">Last</th>
                        <th scope="col">Handle</th>
                    </tr>
                        <td style={{listStyle:"none"}}>{ele.Category}</td>
                        <td style={{listStyle:"none"}}>{ele.Description}</td>
                        
                    </>
                )
              
            }):
            <>
            <p>feels_like=  {responseDataFetch.feels_like}</p>
            <p>humidity=  {responseDataFetch.humidity}</p>
            <p>temp=  {responseDataFetch.temp}</p>
            <p>temp_max=  {responseDataFetch.temp_max}</p>
            <p>temp_min=  {responseDataFetch.temp_min
            }</p>
            </>
            
          
          
            


            }
   
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    
  </tbody>

           
        </div>
          );
       
}

export default Test
