export const counterIncreamentAction = (value) => {
  return (dispatch) => {
      dispatch({
          type:"INCREAMENT_COUNTER",
          payload:value
      })
     
  };
};

export const counterDecreamentAction = (value) => {
  return (dispatch) => {
      dispatch({
        type:"DECREAMENT_COUNTER",
        payload:value
      })
  };
};

