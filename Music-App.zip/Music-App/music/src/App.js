import logo from './logo.svg';
import './App.css';
import Home from '../src/Pages/Home';
import Toggle from './Toggle';
import React from 'react';
import { render } from '@testing-library/react';

function App() {
  return (
    <div className="App">
          
          {/* <DataLayer.Provider value={{ users, dispatchUserEvent }}> */}
          {/* <Home/> */}
          <Toggle/>
      {/* </DataLayer.Provider>
             */}
          
        
      
    </div>
  );
}

export default App;
