function Footer(){
    return(
        <>
        <h1>Music Play Bootom</h1>
        </>
    )
}
export default Footer;