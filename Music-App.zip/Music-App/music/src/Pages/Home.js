import Header from "../Header";
import Footer from "../Footer";
import Container from "@material-ui/core/Container";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import SkipPreviousIcon from "@material-ui/icons/SkipPrevious";
import PlayArrowIcon from "@material-ui/icons/PlayArrow";
import SkipNextIcon from "@material-ui/icons/SkipNext";
import React,{ useState,useEffect } from 'react';
import { Box } from "@material-ui/core";
import axios from "axios";
import { useDataLayerValue } from "../store/ContextApi";
import { createMuiTheme, ThemeProvider } from '@material-ui/core';
import AudioPlayer from 'material-ui-audio-player';
import Icon from '@material-ui/core/Icon';

const muiTheme = createMuiTheme({});

// const [Store, StoreDataApi] = useState([]);



const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    display: "flex",
    justifyContent:"space-around",
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
  details: {
    display: "flex",
    flexDirection: "column",
  },
  newBg: {
    display: "flex",
    flexDirection: "column",
    backgroundColor:"rgb(69 243 13 / 98%)",
    marginBlockEnd:"2px",
  },
  content: {
    flex: "1 0 auto",
  },
  cover: {
    width: 151,
    height:151,
  },
  controls: {
    display: "flex",
    alignItems: "center",
    paddingLeft: theme.spacing(1),
    paddingBottom: theme.spacing(1),
  },
  playIcon: {
    height: 38,
    width: 38,
  },
  innerMusic: {
    fontSize:'10px',
  },
 
  
}));


function Home() {
  
  const [ {name,branch,list,playList} , dispatch] = useDataLayerValue();
  const classes = useStyles();
  const theme = useTheme();
  const [arr, setArr] = useState([])
  const [play, setplay] = useState([1,])



  function addPlalist(songInfo) {
debugger

dispatch({

  type:"PLAY_LIST",
  payload:songInfo
})

  }

  console.log("playList",playList)



  useEffect(() => {
    
    dataFunc()
  }, [])




const dataFunc=()=>{
  axios
  .get(`https://itunes.apple.com/search?term=speed&media=music`)
  .then((res) => {
   
    
    dispatch({

      type:"SONG_LIST",
      payload:res.data.results
    })
    setArr(res.data.results)

  })
  .catch((err) => {
    console.log(err);
  });
}
  return (
    <>
    {/* <ThemeContent.Consumer value="New Value"> */}
    <Header />
      <Grid container  maxwidth="xl">
        <Grid item md={8} style={{widht:'100%'}}>
        <Typography variant="h4" component="h4" gutterBottom>
        Music List
      </Typography>
          <Grid container  >
          {arr?.length > 0 && arr.map(ele=>{
        return <Grid item  md={6} >
        <Box p={2}>
          <Card className={classes.root}>
            <div className={classes.details}>
            <Icon color="primary" onClick={()=>{addPlalist(ele)}}>add_circle</Icon>
              <CardContent className={classes.content}>
                <Typography component="h5" variant="h6">
                  {ele.trackName}
                </Typography>
                <Typography variant="subtitle1" color="textSecondary">
                  {ele.primaryGenreName}
                </Typography>
              </CardContent>
              
              <div className={classes.controls} >
              <ThemeProvider theme={muiTheme}>
              <AudioPlayer
                className={classes.innerMusic}
                useStyles={useStyles}
                src={ele.previewUrl}
                loop={true}
                
              />
              </ThemeProvider>;
                
              </div>
            </div>
            <CardMedia
              className={classes.cover}
              image={ele.artworkUrl100}
              title="Live from space album cover"
            />
          </Card>
        </Box>
      </Grid>
    })}
          </Grid>
        </Grid>
        <Grid item md={4} >
        <Typography variant="h4" component="h4" gutterBottom>
        PlayList List Song
      </Typography>
          <Grid container   >
          {playList?.length > 0 && playList.map(ele=>{
        return <Grid item className={classes.newBg} md={12} >
        <Box p={2} >
          <Card className={classes.root}>
            <div className={classes.detailsnew}>
              <CardContent className={classes.content}>
                <Typography  component="h5" variant="h5">
                  {ele.trackName}
                </Typography>
                <Typography variant="subtitle1" color="textSecondary">
                  {ele.primaryGenreName}
                </Typography>
              </CardContent>
              <div className={classes.controls}>
                <IconButton aria-label="previous">
                  {theme.direction === "rtl" ? (
                    <SkipNextIcon />
                  ) : (
                    <SkipPreviousIcon />
                  )}
                </IconButton>
                <IconButton aria-label="play/pause">
                  <PlayArrowIcon className={classes.playIcon} />
                </IconButton>
                <IconButton aria-label="next">
                  {theme.direction === "rtl" ? (
                    <SkipPreviousIcon />
                  ) : (
                    <SkipNextIcon />
                  )}
                </IconButton>
              </div>
            </div>
            <CardMedia
              className={classes.cover}
              image={ele.artworkUrl100}
              title="Live from space album cover"
            />
          </Card>
        </Box>
      </Grid>
    })}
          </Grid>
   
         

        </Grid>
        
    

        
     
      </Grid>
      <Footer />
    {/* </ThemeContent.Consumer> */}
     
    </>
  );
}

export default Home;
