import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { DataLayer } from "./store/ContextApi"
import reducer, { intialState } from "./store/Reducer"

ReactDOM.render(
  <React.StrictMode>
    <DataLayer intialState={intialState} reducer={reducer}>
          <App/>
      </DataLayer>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
