import React, { createContext, useContext, useReducer } from "react";

export const StateContext = createContext();

export const DataLayer = ({ intialState, reducer, children }) => (
  <StateContext.Provider value={useReducer(reducer, intialState)}>
    {children}
  </StateContext.Provider>
);

export const useDataLayerValue = () => useContext(StateContext);
