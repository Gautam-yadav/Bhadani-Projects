import { CallToAction } from "@material-ui/icons";

export const intialState = {
    name: "Gautam123",
    branch:"",
    list:[],
    playList:[]
}

const reducer = (state = intialState, action) => {
  
    switch (action.type) {
        case "Org_Already_Data": {
          return {
            ...state,
            branch:action.payload,
            // org_Frnd_Name: action.payload.org_Frnd_Name,
            // org_legal_Name: action.payload.org_legal_Name,
            // org_title_name: action.payload.org_title_name,
            // org_address: action.payload.org_address,
            // name : action.payload,
          };
        }
        case "SONG_LIST": {
          return {
            ...state,
            list:action.payload,
          
          };
        }
        case "PLAY_LIST": {
          debugger
            
          return {
            
            ...state,
            // playList:[action.payload],
            playList: [...state.playList, action.payload]
          
          };
        }
        default:
      return state;
  }
}

export default reducer;

